create trigger delete_teacher_to_user
  after DELETE
  on t_teacher
  for each row
  BEGIN 
 DELETE FROM t_user WHERE userNo=OLD.teacherNo;
END;

