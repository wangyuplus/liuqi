create trigger insert_teacherNo_to_user
  after INSERT
  on t_teacher
  for each row
  BEGIN
INSERT INTO t_user VALUES(null,NEW.teacherNo,'6666',2);
END;

